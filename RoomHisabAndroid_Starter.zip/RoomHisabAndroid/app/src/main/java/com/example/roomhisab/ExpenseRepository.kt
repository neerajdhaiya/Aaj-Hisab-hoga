package com.example.roomhisab

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

class ExpenseRepository(private val dao: ExpenseDao) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    val expenses: Flow<List<Expense>> = dao.observeAll()

    fun add(title: String, amountPaise: Long, paidBy: String) {
        scope.launch {
            dao.insert(Expense(title = title, amountPaise = amountPaise, paidBy = paidBy))
        }
    }

    fun clearAll() {
        scope.launch { dao.clearAll() }
    }
}
