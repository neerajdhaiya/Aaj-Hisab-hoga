package com.example.roomhisab

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "expenses")
data class Expense(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val amountPaise: Long,
    val paidBy: String,
    val createdAt: Long = System.currentTimeMillis(),
    val synced: Boolean = false
)

@Dao
interface ExpenseDao {
    @Query("SELECT * FROM expenses ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<Expense>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(expense: Expense)

    @Query("DELETE FROM expenses")
    suspend fun clearAll()
}

@Database(entities = [Expense::class], version = 1, exportSchema = false)
abstract class RoomHisabDatabase : RoomDatabase() {
    abstract fun expenseDao(): ExpenseDao

    companion object {
        @Volatile private var INSTANCE: RoomHisabDatabase? = null
        fun getInstance(context: Context): RoomHisabDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    RoomHisabDatabase::class.java,
                    "room_hisab.db"
                ).build().also { INSTANCE = it }
            }
    }
}
