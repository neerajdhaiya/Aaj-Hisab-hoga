package com.example.roomhisab

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import java.text.NumberFormat
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = RoomHisabDatabase.getInstance(applicationContext)
        val repository = ExpenseRepository(db.expenseDao())
        setContent { MaterialTheme { RoomHisabScreen(repository) } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoomHisabScreen(repository: ExpenseRepository) {
    val expenses by repository.expenses.collectAsState(initial = emptyList())
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var paidBy by remember { mutableStateOf("Member 1") }
    val members = listOf("Member 1", "Member 2", "Member 3", "Member 4", "Member 5")
    val total = expenses.sumOf { it.amountPaise }
    val currency = NumberFormat.getCurrencyInstance(Locale("en", "IN"))

    Scaffold(topBar = { TopAppBar(title = { Text("🏠 Room Hisab") }) }) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card {
                    Column(Modifier.padding(16.dp)) {
                        Text("Monthly total", style = MaterialTheme.typography.titleMedium)
                        Text(currency.format(total / 100.0), style = MaterialTheme.typography.headlineMedium)
                        Text("Per person (5 members): ${currency.format(total / 5 / 100.0)}")
                    }
                }
            }
            item { Text("Add expense", style = MaterialTheme.typography.titleLarge) }
            item {
                OutlinedTextField(title, { title = it }, label = { Text("Expense (e.g. Rent, Gas, Milk)") }, modifier = Modifier.fillMaxWidth())
            }
            item {
                OutlinedTextField(amount, { amount = it }, label = { Text("Amount in ₹") }, modifier = Modifier.fillMaxWidth())
            }
            item {
                var expanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                    OutlinedTextField(
                        value = paidBy, onValueChange = {}, readOnly = true,
                        label = { Text("Paid by") }, modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        members.forEach { member ->
                            DropdownMenuItem(text = { Text(member) }, onClick = { paidBy = member; expanded = false })
                        }
                    }
                }
            }
            item {
                Button(
                    onClick = {
                        val value = amount.toDoubleOrNull()
                        if (title.isNotBlank() && value != null && value > 0) {
                            repository.add(title.trim(), (value * 100).toLong(), paidBy)
                            title = ""; amount = ""
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Save expense") }
            }
            item { Text("Expense history", style = MaterialTheme.typography.titleLarge) }
            if (expenses.isEmpty()) {
                item { Text("Abhi koi expense add nahi hua.") }
            } else {
                items(expenses, key = { it.id }) { expense ->
                    Card {
                        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(Modifier.weight(1f)) {
                                Text(expense.title, style = MaterialTheme.typography.titleMedium)
                                Text("Paid by: ${expense.paidBy}", style = MaterialTheme.typography.bodySmall)
                            }
                            Text(currency.format(expense.amountPaise / 100.0))
                        }
                    }
                }
            }
            item {
                OutlinedButton(onClick = { repository.clearAll() }, modifier = Modifier.fillMaxWidth()) {
                    Text("Clear all expenses")
                }
            }
        }
    }
}
