# Room Hisab Android starter

यह Android Studio के लिए शुरुआती प्रोजेक्ट है।

## अभी क्या काम करता है
- पाँच सदस्यों के लिए शुरुआती विकल्प
- किराया/बिजली/राशन/अन्य खर्च जैसे किसी भी नाम से खर्च जोड़ना
- किस सदस्य ने भुगतान किया, उसका रिकॉर्ड
- कुल खर्च और पाँच लोगों में बराबर हिस्सा
- Room database के जरिए फोन में offline रिकॉर्ड

## Android Studio में चलाएँ
1. ZIP extract करें।
2. Android Studio में `RoomHisabAndroid` फ़ोल्डर खोलें।
3. Gradle sync पूरा होने दें।
4. Android Emulator या अपने Android फोन पर Run दबाएँ।

## Online sync अभी setup बाकी है
Firebase Cloud Firestore की dependency शामिल है, लेकिन online sync चालू करने के लिए:
1. Firebase Console में नया project बनाएँ।
2. Android app package `com.example.roomhisab` जोड़ें।
3. `google-services.json` को `app/` फ़ोल्डर में रखें।
4. Firebase Authentication (email/Google) और Firestore enable करें।
5. सदस्य-आधारित access rules सेट करें और फिर sync layer जोड़ें।

**महत्वपूर्ण:** इस starter में अभी cloud sync/authentication सक्रिय नहीं है। अभी डेटा फोन में offline सेव होता है। पाँचों फोन में साझा हिसाब करने से पहले login, room code, cloud sync और security rules लागू करना ज़रूरी है।
